import pyautogui
import time
import os
import ctypes  # For requesting administrator rights
import keyboard  # For simulating key presses

# Function to check and request administrator rights
def check_admin_rights():
    try:
        # Check if the script is running with administrator rights
        is_admin = ctypes.windll.shell32.IsUserAnAdmin()
        if not is_admin:
            # If not, request administrator rights
            ctypes.windll.shell32.ShellExecuteW(None, "runas", __file__, None, None, 1)
    except Exception as e:
        # If an error occurs, display a message and exit
        print("Failed to request administrator rights:", e)
        exit()

# Request administrator rights
check_admin_rights()

# Path to the folder containing images to search for
folder_path = r'C:\Users\PICARINA\Desktop\q\opop'

# Get a list of all PNG files in the specified folder
image_files = [f for f in os.listdir(folder_path) if f.endswith('.png')]

# Define the screen region for image search
# x1, y1 - coordinates of the top-left corner; width, height - dimensions of the region
x1, y1, width, height = 811, 376, 295, 270

# Coordinates for clicks (in pixels)
click_coords = (1829, 1001)

# Sequence of key presses to be performed cyclically with a 30-second delay
keys = ["a", "a", "a", "a", "a", "a", "a", "d", "d", "d", "d", "d", "d", "d", "d", 
        "d", "d", "d", "d", "d", "d", "d", "d", "d", "d", "a", "a", "a", "a", "a", 
        "a", "a", "a", "a", "a", "a", "a"]

# Time of the last key press (to enforce the 30-second interval)
last_key_press_time = time.time()

# Function to simulate key presses
def press_keys():
    global last_key_press_time
    current_time = time.time()

    # Check if 30 seconds have passed since the last key press
    if current_time - last_key_press_time >= 30:
        # Take the first key from the sequence and move it to the end (cyclical behavior)
        key = keys.pop(0)
        keys.append(key)

        # Simulate the key press and log it to the console
        print(f"Pressing '{key.upper()}'...")
        keyboard.press(key)
        time.sleep(0.2)  # Delay to mimic natural key press
        keyboard.release(key)

        # Update the time of the last key press
        last_key_press_time = time.time()

# Main program loop
while True:
    # Iterate through all images in the folder
    for image_file in image_files:
        image_path = os.path.join(folder_path, image_file)  # Full path to the image
        print(f"Attempting to find image: {image_path}")
        
        try:
            # Search for the image on the screen within the defined region and confidence level
            location = pyautogui.locateOnScreen(image_path, confidence=0.8, region=(x1, y1, width, height))

            if location:
                # If the image is found, click its center
                pyautogui.click(pyautogui.center(location))
                print(f"Clicked on image {image_file}")
                
                # Perform additional actions if the image matches specific cases (e.g., "meshok")
                if image_file in ["meshok.png", "meshok2.png"]:
                    time.sleep(2)  # Wait before the next step
                    pyautogui.moveTo(click_coords)  # Move cursor to specific coordinates
                    pyautogui.click()  # Perform the click
                    print(f"Clicked at coordinates {click_coords}")
                    time.sleep(2)  # Delay before continuing
                else:
                    # Wait 12 seconds for regular images before proceeding
                    time.sleep(12)
            else:
                # If the image is not found, log a message and pause briefly
                print(f"Image {image_file} not found.")
                time.sleep(0.5)
        except pyautogui.ImageNotFoundException:
            # Handle the exception if the image is not found
            print(f"Image {image_file} not found. Retrying...")
            time.sleep(0.5)

    # After processing all images, call the function to simulate key presses
    press_keys()
