import pyautogui
import time
import os
import ctypes  # Для запроса прав администратора
import keyboard  # Для имитации нажатий клавиш

# Функция для проверки и запроса прав администратора
def check_admin_rights():
    try:
        # Проверяем, запущен ли скрипт с правами администратора
        is_admin = ctypes.windll.shell32.IsUserAnAdmin()
        if not is_admin:
            # Если права администратора отсутствуют, запрашиваем их
            ctypes.windll.shell32.ShellExecuteW(None, "runas", __file__, None, None, 1)
    except Exception as e:
        # В случае ошибки выводим сообщение и завершаем выполнение
        print("Не удалось запросить права администратора:", e)
        exit()

# Устанавливаем админские права
check_admin_rights()

# Путь к папке с изображениями, которые будем искать на экране
folder_path = r'C:\Users\PICARINA\Desktop\q\opop'

# Получаем список всех PNG-файлов в указанной папке
image_files = [f for f in os.listdir(folder_path) if f.endswith('.png')]

# Устанавливаем границы области экрана, где будет происходить поиск изображений
# x1, y1 - координаты верхнего левого угла; width, height - ширина и высота области
x1, y1, width, height = 811, 376, 295, 270

# Координаты для кликов (в пикселях)
click_coords = (1829, 1001)

# Последовательность нажатий клавиш, которая будет циклически повторяться
keys = ["a", "a", "a", "a", "a", "a", "a", "d", "d", "d", "d", "d", "d", "d", "d", 
        "d", "d", "d", "d", "d", "d", "d", "d", "d", "d", "a", "a", "a", "a", "a", 
        "a", "a", "a", "a", "a", "a", "a"]

# Время последнего нажатия клавиш (чтобы отслеживать 30-секундный интервал)
last_key_press_time = time.time()

# Функция для имитации нажатий клавиш
def press_keys():
    global last_key_press_time
    current_time = time.time()

    # Проверяем, прошло ли 30 секунд с последнего нажатия клавиш
    if current_time - last_key_press_time >= 30:
        # Берем первое значение из последовательности и переносим его в конец (цикличность)
        key = keys.pop(0)
        keys.append(key)

        # Нажимаем клавишу и выводим её в консоль
        print(f"Нажимаю '{key.upper()}'...")
        keyboard.press(key)
        time.sleep(0.2)  # Задержка, чтобы имитировать естественное нажатие
        keyboard.release(key)

        # Обновляем время последнего нажатия
        last_key_press_time = time.time()

# Основной цикл программы
while True:
    # Проходим по всем изображениям из папки
    for image_file in image_files:
        image_path = os.path.join(folder_path, image_file)  # Полный путь к изображению
        print(f"Пытаюсь найти изображение: {image_path}")
        
        try:
            # Ищем изображение на экране в указанной области с заданной точностью (confidence)
            location = pyautogui.locateOnScreen(image_path, confidence=0.8, region=(x1, y1, width, height))

            if location:
                # Если изображение найдено, кликаем по его центру
                pyautogui.click(pyautogui.center(location))
                print(f"Клик по изображению {image_file}")
                
                # Если это специальное изображение (например, "мешок"), выполняем дополнительные действия
                if image_file in ["meshok.png", "meshok2.png"]:
                    time.sleep(2)  # Небольшая задержка перед следующим шагом
                    pyautogui.moveTo(click_coords)  # Перемещаем курсор к заданным координатам
                    pyautogui.click()  # Выполняем клик
                    print(f"Клик на координаты {click_coords}")
                    time.sleep(2)  # Задержка перед продолжением
                else:
                    # Если изображение обычное, ждем 12 секунд перед следующей итерацией
                    time.sleep(12)
            else:
                # Если изображение не найдено, выводим сообщение и делаем паузу
                print(f"Изображение {image_file} не найдено.")
                time.sleep(0.5)
        except pyautogui.ImageNotFoundException:
            # Обрабатываем исключение, если изображение не найдено
            print(f"Изображение {image_file} не найдено. Повторная попытка...")
            time.sleep(0.5)

    # После обработки всех изображений вызываем функцию для нажатия клавиш
    press_keys()
