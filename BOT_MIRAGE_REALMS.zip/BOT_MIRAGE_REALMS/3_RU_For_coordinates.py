import tkinter as tk
from pynput.mouse import Listener

# Function to handle mouse movement
def on_move(x, y):
    # Update the label with the current mouse coordinates
    label.config(text=f"x = {x}, y = {y}")

# Create the main application window
root = tk.Tk()
root.title("Mouse Coordinates")  # Set the window title
root.geometry("200x50")  # Set the window size
root.resizable(False, False)  # Disable resizing of the window

# Create a label widget to display mouse coordinates
label = tk.Label(root, font=("Helvetica", 10), bg="white", fg="black")
label.pack()  # Add the label to the window

# Start a mouse event listener to track mouse movement
listener = Listener(on_move=on_move)
listener.start()

# Position the window in the top-left corner of the screen
root.attributes("-topmost", True)  # Ensure the window stays on top of other windows
root.geometry(f"200x50+0+0")  # Set the window's position (200x50 size, top-left corner)

# Start the graphical user interface (GUI) event loop
root.mainloop()
